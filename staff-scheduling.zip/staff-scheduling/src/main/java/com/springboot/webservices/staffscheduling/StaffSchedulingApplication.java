package com.springboot.webservices.staffscheduling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StaffSchedulingApplication {

	public static void main(String[] args) {
		SpringApplication.run(StaffSchedulingApplication.class, args);
	}

}
